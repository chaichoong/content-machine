# Operations Director — WordPress Theme

**Version 2.0 — single-offer launch (£1,997 + £247/month)**

This is the launch theme. Single offer, Book a Call funnel, no self-serve checkout, no equity option, no module marketplace pricing. See `COPY-SPEC.md` for the locked copy and rules.

## What changed in 2.0

- Pricing reduced from three tiers to one offer: £1,997 implementation + £247/month from month 4
- All CTAs now route to the GoHighLevel booking link (`https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0`)
- Stripped £49/£149/£299 references from homepage, header mega menus, footer, modal and JS
- Module cards no longer show per-module pricing — they show "Included" instead
- Modal CTA changed from "Install module" to "Book a conversation"
- FAQ page rewritten to match the single-offer launch
- Footer HTML bugs fixed (`<ahref` and `<button href>` typos)
- Brand description updated across header and footer

## What's inside

```
operations-director/
├── style.css           WP theme metadata (v2.0.0)
├── COPY-SPEC.md        Locked copy spec — read this before changing anything
├── functions.php       Enqueues CSS/JS, exposes page URLs to JS
├── header.php          DOCTYPE, <head>, nav + mega menus, Book a Call CTA
├── footer.php          Modal overlay + site footer + wp_footer()
├── front-page.php      Home (single offer, Book a Call funnel)
├── page-about.php      About Kevin          (Template Name: About)
├── page-optimise.php   OPTIMISE framework   (Template Name: OPTIMISE Framework)
├── page-faq.php        FAQ                  (Template Name: FAQ)
├── page.php            Generic page fallback
├── index.php           WP-required fallback
├── 404.php             Not-found page
├── README.md           This file
└── assets/
    ├── css/main.css    All styles (v2.0 additions appended at bottom)
    └── js/main.js      Module data (no per-module prices), modal, mega nav
```

## Deployment

1. **Zip the theme folder**
   - Zip the `operations-director` folder so the zip contains the folder, not its contents.

2. **Upload to WordPress (Hostinger)**
   - hPanel → Websites → Manage → WordPress → Dashboard
   - WP admin → Appearance → Themes → Add New → Upload Theme → Install Now → Activate

3. **Confirm pages exist with correct slugs and templates**

   | Page title | Slug | Template (Page Attributes) |
   |---|---|---|
   | Home | `home` | Default |
   | About | `about` | About |
   | OPTIMISE | `optimise` | OPTIMISE Framework |
   | FAQ | `faq` | FAQ |

   If pages already exist from v1.1, no change needed. Leave content editor empty — templates render everything.

4. **Reading settings**
   - Settings → Reading → Your homepage displays → A static page → Home → Save

5. **Permalinks**
   - Settings → Permalinks → Post name → Save

6. **Smoke test (5 minutes)**
   - Open homepage. Confirm hero says "Your business runs on you. That's the problem."
   - Confirm pricing section shows £1,997 + £247/month.
   - Click "Book a conversation" — confirm it opens the GHL booking link in a new tab.
   - Click any module card — confirm modal shows "Book a conversation" as primary CTA, not "Install module".
   - Open `/faq/` — confirm questions reference the new offer, not Solo/Team/Full OS.
   - Test on mobile (375px width) — nav should collapse, hero should scale, all CTAs should be tappable.

## What is NOT in this build

Per the launch decision, none of the following are included:

- Self-serve Stripe checkout (Phase 3 only)
- Equity offer page (decision: dropped at this price point)
- Tier comparison (Solo/Team/Full OS) — single offer only
- Lead magnet or email capture forms
- Testimonials or case studies (none yet)
- Live chat widget
- Cookie banner

## Editing copy later

All copy lives in PHP templates. WordPress admin will not edit it. To change copy:

1. Edit the relevant `.php` file
2. Re-upload the theme zip via Appearance → Themes → Add New → Upload (replaces existing)

If you need WP-admin-editable content, that's a separate task — convert templates to use `the_content()` plus ACF.

## Booking link — single source of truth

Every CTA on the site routes to:

`https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0`

If this link changes, search-and-replace across the theme (it appears in `front-page.php`, `header.php`, `footer.php`, `page-faq.php`).

## Rollback

If anything breaks, Appearance → Themes → switch back to the previous theme. Pages and settings stay intact.
