<?php
/**
 * Template Name: Terms
 * Description: Terms & Conditions, Service Agreement and Privacy notice for Operations Director Ltd.
 *
 * @package OperationsDirector
 */
get_header();
?>
<main class="od-page-terms">

  <!-- ============== HERO ============== -->
  <header class="legal-hero">
    <div class="legal-hero-inner">
      <div class="legal-eyebrow">Legal</div>
      <h1>Terms &amp; Conditions</h1>
      <p class="legal-subtitle">The rules of using this website, the agreement we sign when you buy our services, and how we handle your data.</p>
    </div>
  </header>

  <!-- ============== TWO-COLUMN LAYOUT ============== -->
  <div class="legal-wrap">
    <div class="legal-grid">

      <!-- TOC -->
      <aside class="legal-toc">
        <div class="toc-card">
          <div class="toc-title">On this page</div>
          <nav>
            <a href="#about">1. About these terms</a>
            <a href="#parties">2. Who we are</a>
            <a href="#part-a">Part A — Website Terms of Use</a>
            <a href="#a-acceptance" class="sub">A1. Acceptance &amp; eligibility</a>
            <a href="#a-content" class="sub">A2. Content &amp; IP</a>
            <a href="#a-acceptable" class="sub">A3. Acceptable use</a>
            <a href="#a-thirdparty" class="sub">A4. Third-party links</a>
            <a href="#a-disclaimer" class="sub">A5. Disclaimer</a>
            <a href="#part-b">Part B — Service Agreement</a>
            <a href="#b-services" class="sub">B1. Services</a>
            <a href="#b-fees" class="sub">B2. Fees &amp; payment</a>
            <a href="#b-term" class="sub">B3. Term &amp; termination</a>
            <a href="#b-deliverables" class="sub">B4. Deliverables &amp; IP</a>
            <a href="#b-clientduties" class="sub">B5. Your responsibilities</a>
            <a href="#b-confidentiality" class="sub">B6. Confidentiality</a>
            <a href="#b-data" class="sub">B7. Data protection</a>
            <a href="#b-warranties" class="sub">B8. Warranties</a>
            <a href="#b-liability" class="sub">B9. Liability</a>
            <a href="#b-force" class="sub">B10. Force majeure</a>
            <a href="#part-c">Part C — Privacy notice</a>
            <a href="#general">General provisions</a>
            <a href="#contact">Contact</a>
          </nav>
        </div>
      </aside>

      <!-- BODY -->
      <article class="legal-body">

        <section id="about">
          <h2>1. About these terms</h2>
          <p>This page sets out the legal terms that apply when you use the Operations Director website and when you buy our services. It is split into three parts:</p>
          <ul class="prose-list">
            <li><strong>Part A — Website Terms of Use:</strong> the rules for using this website. These apply to every visitor.</li>
            <li><strong>Part B — Service Agreement:</strong> the contract that governs our paid services (including the £1,997 setup, which covers the first 30 days, plus £247/month subscription thereafter). These apply if you become a customer.</li>
            <li><strong>Part C — Privacy notice:</strong> how we collect, use and protect personal data.</li>
          </ul>
          <p>By using this website you accept Part A. By purchasing services or signing a proposal, you also accept Part B. We may update these terms; the version in force at the time you place an order is the version that applies to that order.</p>
        </section>

        <section id="parties">
          <h2>2. Who we are</h2>
          <div class="info-card">
            <div class="info-row"><span class="info-label">Trading name</span><span class="info-value">Operations Director</span></div>
            <div class="info-row"><span class="info-label">Legal entity</span><span class="info-value">Operations Director Ltd</span></div>
            <div class="info-row"><span class="info-label">Contact email</span><span class="info-value"><a href="mailto:hello@operationsdirector.co.uk">hello@operationsdirector.co.uk</a></span></div>
          </div>
        </section>

        <!-- ================= PART A ================= -->
        <div class="part-divider" id="part-a">
          <div class="part-tag">Part A</div>
          <h2 class="part-heading">Website Terms of Use</h2>
        </div>

        <section id="a-acceptance">
          <h3>A1. Acceptance and eligibility</h3>
          <p>By accessing or using this website you agree to these Terms of Use. If you do not agree, do not use the site. You must be at least 18 years old and have the legal capacity to enter into a binding agreement.</p>
        </section>

        <section id="a-content">
          <h3>A2. Content and intellectual property</h3>
          <p>All content on this website — including text, graphics, logos, frameworks (such as the OPTIMISE framework), code samples, videos, images and module descriptions — is owned by Operations Director Ltd or licensed to us, and is protected by UK and international intellectual property law.</p>
          <p>You may view, download and print pages for your own personal or internal business reference. You may not:</p>
          <ul class="prose-list">
            <li>Republish, copy or redistribute material from this site without our written permission.</li>
            <li>Use any content for commercial purposes other than as expressly permitted.</li>
            <li>Remove copyright, trade mark or other proprietary notices.</li>
            <li>Use automated tools to scrape, mirror or harvest content.</li>
          </ul>
        </section>

        <section id="a-acceptable">
          <h3>A3. Acceptable use</h3>
          <p>You agree not to use the website in any way that is unlawful, harmful, or that interferes with its operation. In particular you agree not to:</p>
          <ul class="prose-list">
            <li>Submit false, misleading or fraudulent information through any form.</li>
            <li>Attempt to gain unauthorised access to any part of the site, server or related systems.</li>
            <li>Introduce viruses, malware or other malicious code.</li>
            <li>Use the site to transmit unsolicited commercial communications.</li>
          </ul>
        </section>

        <section id="a-thirdparty">
          <h3>A4. Third-party links and services</h3>
          <p>The website may link to third-party websites, products and integrations (including, for example, Airtable, Slack, Make.com, GoHighLevel, Google Workspace and similar tools). We are not responsible for the content, terms, availability or practices of any third-party site or service. Linking does not imply endorsement.</p>
        </section>

        <section id="a-disclaimer">
          <h3>A5. Disclaimer</h3>
          <p>The website is provided <em>"as is"</em>. We make no warranty that the site will be uninterrupted, error-free, secure, or fit for any particular purpose. Information on the site is provided for general guidance and does not constitute professional, legal, financial or operational advice. You should take your own advice before acting on anything you read here.</p>
        </section>

        <!-- ================= PART B ================= -->
        <div class="part-divider" id="part-b">
          <div class="part-tag">Part B</div>
          <h2 class="part-heading">Service Agreement</h2>
          <p class="part-intro">These terms apply when you engage Operations Director Ltd to deliver services, including (but not limited to) the Operations OS product priced at £1,997 setup (which covers the build and the first 30 days of subscription access) plus £247 per month thereafter. They form a contract between you (the <strong>Client</strong>) and us.</p>
        </div>

        <section id="b-services">
          <h3>B1. Scope of services</h3>
          <p>The specific services you are purchasing will be described in a written proposal, statement of work, order form or product page (the <strong>Order</strong>). The Order, together with these terms, forms the entire agreement for that engagement. Where the Order conflicts with these terms, the Order prevails for that specific engagement.</p>
          <p>Unless agreed otherwise in writing, our standard Operations OS product includes:</p>
          <ul class="prose-list">
            <li>Discovery and scoping of your business operations.</li>
            <li>Build and configuration of selected modules from our marketplace, using third-party tools licensed in your name (Airtable, Slack, Make.com, etc.).</li>
            <li>Onboarding, training and a documented operating manual.</li>
            <li>Ongoing support and iteration during the active subscription period.</li>
          </ul>
        </section>

        <section id="b-fees">
          <h3>B2. Fees, invoicing and payment</h3>
          <ul class="prose-list">
            <li><strong>Setup fee:</strong> £1,997 (or as stated in your Order) is payable in full at signup, before build work begins, unless we agree a written payment plan. The setup fee covers the build, onboarding, and your first 30 days of subscription access from the signup date — no monthly fee is charged during this period.</li>
            <li><strong>Monthly subscription:</strong> £247 per month (or as stated in your Order) commences on day 31 after the signup date and is payable monthly in advance by Direct Debit, standing order or card.</li>
            <li><strong>VAT:</strong> all fees are exclusive of VAT, which will be added at the prevailing rate where applicable.</li>
            <li><strong>Third-party costs:</strong> licence fees for the underlying tools (Airtable, Slack, Make.com, etc.) are paid by you directly to those providers and are not included in our fees.</li>
            <li><strong>Late payment:</strong> we may suspend services and charge statutory interest under the Late Payment of Commercial Debts (Interest) Act 1998 if any invoice is overdue.</li>
            <li><strong>Price changes:</strong> we may change subscription pricing on at least 30 days' written notice. You may cancel before the new price takes effect.</li>
          </ul>
        </section>

        <section id="b-term">
          <h3>B3. Term, cancellation and termination</h3>
          <ul class="prose-list">
            <li><strong>Minimum term:</strong> the monthly subscription has a minimum initial term of 3 paid months, commencing on day 31 after the signup date. This is in addition to the first 30 days included in the setup fee, giving a total minimum commitment of 4 months from the signup date.</li>
            <li><strong>After the minimum term:</strong> the subscription continues monthly until cancelled by either party giving at least 30 days' written notice.</li>
            <li><strong>Setup fee refunds:</strong> the setup fee is non-refundable once build work has commenced. If you cancel before build work begins, you will receive a refund less any time already incurred at our standard rate.</li>
            <li><strong>Cancellation during the first 30 days:</strong> you may cancel at any time during the first 30 days, but the setup fee remains non-refundable once build work has commenced as set out above. No further charges will be raised if you cancel within this period.</li>
            <li><strong>Consumer cooling-off:</strong> if you contract as a consumer (not in the course of a business), you have a 14-day right to cancel under the Consumer Contracts Regulations 2013. Where you ask us to start work within that period, you accept that you may be charged for work done up to the point of cancellation.</li>
            <li><strong>Termination for cause:</strong> either party may terminate immediately if the other party commits a material breach that is not remedied within 14 days of written notice, or becomes insolvent.</li>
            <li><strong>On termination:</strong> you remain liable for fees accrued up to the termination date. We will provide a reasonable handover and access to your data for 30 days following termination.</li>
          </ul>
        </section>

        <section id="b-deliverables">
          <h3>B4. Deliverables and intellectual property</h3>
          <ul class="prose-list">
            <li><strong>Your data:</strong> all data you input into the systems we build remains your property at all times.</li>
            <li><strong>Bespoke configurations:</strong> Airtable bases, automations, dashboards, SOPs and other configurations built specifically for your business are licensed to you on a perpetual, royalty-free basis for use in your business, conditional on payment of all sums due.</li>
            <li><strong>Our background IP:</strong> our underlying frameworks, methodologies (including the OPTIMISE framework), template skills, prompt libraries, code libraries and reusable components remain our property. We grant you a non-exclusive, non-transferable licence to use them as embedded in your deliverables for the purpose of running your business.</li>
            <li><strong>Third-party tools:</strong> tools such as Airtable, Slack, Make.com and similar remain governed by their own terms and licences. Accounts are typically held in your name.</li>
            <li><strong>Reuse:</strong> we may reuse generic methods, learnings and non-confidential improvements in work for other clients.</li>
          </ul>
        </section>

        <section id="b-clientduties">
          <h3>B5. Your responsibilities</h3>
          <p>To allow us to deliver the services on time and to budget, you agree to:</p>
          <ul class="prose-list">
            <li>Provide accurate information about your business, processes and current systems.</li>
            <li>Make available the people, access credentials and decisions we reasonably need.</li>
            <li>Pay third-party tool subscriptions directly and keep them in good standing.</li>
            <li>Respond to requests for input within a reasonable time. Unreasonable delays may extend the timeline and, where they cause additional work, may incur additional fees agreed in advance.</li>
          </ul>
        </section>

        <section id="b-confidentiality">
          <h3>B6. Confidentiality</h3>
          <p>Each party will keep confidential any non-public information disclosed by the other in connection with the services, and will use it only for the purpose of performing this agreement. This obligation continues for three years after termination. It does not apply to information that is or becomes public through no fault of the receiving party, or that must be disclosed by law.</p>
        </section>

        <section id="b-data">
          <h3>B7. Data protection</h3>
          <p>Where we process personal data on your behalf in the course of delivering the services, we do so as a processor and you are the controller, in accordance with the UK GDPR and the Data Protection Act 2018. A separate Data Processing Agreement may be entered into where required. Each party will comply with applicable data protection law.</p>
          <p>See <a href="#part-c">Part C — Privacy notice</a> for how we handle personal data we collect directly (for example, when you enquire through this website).</p>
        </section>

        <section id="b-warranties">
          <h3>B8. Warranties</h3>
          <p>We warrant that we will perform the services with reasonable care and skill, in accordance with good industry practice. To the maximum extent permitted by law, all other warranties, conditions or terms (whether express or implied by statute, common law, custom or otherwise) are excluded. We do not warrant that the systems we build will be free from defects or that automation outcomes will meet any specific business target.</p>
        </section>

        <section id="b-liability">
          <h3>B9. Limitation of liability</h3>
          <div class="callout">
            <div class="callout-label">Important</div>
            <p>Nothing in this agreement excludes or limits liability for: death or personal injury caused by negligence; fraud or fraudulent misrepresentation; or any other liability that cannot be excluded or limited by law.</p>
          </div>
          <p>Subject to the paragraph above:</p>
          <ul class="prose-list">
            <li>Neither party is liable for indirect, consequential, special or punitive losses, including loss of profit, loss of revenue, loss of business opportunity, loss of data (beyond our duty to keep reasonable backups during the engagement) or loss of goodwill.</li>
            <li>Our total aggregate liability under or in connection with this agreement, in contract, tort (including negligence) or otherwise, is capped at the total fees paid by you to us in the 12 months immediately before the event giving rise to the claim, or £10,000, whichever is the lower.</li>
          </ul>
        </section>

        <section id="b-force">
          <h3>B10. Force majeure</h3>
          <p>Neither party is liable for delay or failure to perform caused by events beyond its reasonable control, including failure of public infrastructure or third-party platforms, industrial action, pandemic, war, or government action. The affected party will notify the other promptly and use reasonable efforts to resume performance.</p>
        </section>

        <!-- ================= PART C ================= -->
        <div class="part-divider" id="part-c">
          <div class="part-tag">Part C</div>
          <h2 class="part-heading">Privacy notice</h2>
          <p class="part-intro">This summary explains how we handle personal data collected through this website and our enquiry processes. It is provided in addition to any standalone Privacy Policy.</p>
        </div>

        <section id="c-summary">
          <h3>What we collect and why</h3>
          <ul class="prose-list">
            <li><strong>Identity and contact data</strong> (name, email, phone, business name) — when you submit an enquiry or book a call. Used to respond to you and deliver services. Lawful basis: contract / legitimate interests.</li>
            <li><strong>Communications</strong> — emails, call recordings, chat messages. Used to deliver services and improve them. Lawful basis: legitimate interests.</li>
            <li><strong>Technical data</strong> — IP address, device, browser, pages visited, via standard analytics. Used to operate and improve the website. Lawful basis: legitimate interests / consent for non-essential cookies.</li>
            <li><strong>Marketing preferences</strong> — used to send relevant updates if you have opted in. Lawful basis: consent. You can withdraw consent at any time.</li>
          </ul>
          <h3>Sharing</h3>
          <p>We share personal data only with: our staff and contractors under confidentiality obligations; the technology providers that run our stack (such as Google Workspace, Airtable, GoHighLevel, Slack and Make.com), acting as processors; professional advisers; and authorities where required by law.</p>
          <h3>Storage and retention</h3>
          <p>Data is stored on services located in the UK, EEA, or other jurisdictions covered by appropriate safeguards. We keep personal data only for as long as needed for the purpose collected, and to comply with legal, accounting and reporting requirements.</p>
          <h3>Your rights</h3>
          <p>Under UK GDPR you have rights to access, rectify, erase, restrict, object to and port your personal data, and to withdraw consent. To exercise any right, email <a href="mailto:hello@operationsdirector.co.uk">hello@operationsdirector.co.uk</a>.</p>
        </section>

        <!-- ================= GENERAL ================= -->
        <div class="part-divider" id="general">
          <div class="part-tag">General</div>
          <h2 class="part-heading">General provisions</h2>
        </div>

        <section id="g-general">
          <ul class="prose-list">
            <li><strong>Entire agreement:</strong> these terms together with any Order form the entire agreement between you and us, and supersede prior discussions.</li>
            <li><strong>No partnership:</strong> nothing in these terms creates a partnership, joint venture or employment relationship.</li>
            <li><strong>Assignment:</strong> you may not assign your rights without our written consent. We may assign on notice as part of a sale or restructure.</li>
            <li><strong>Third-party rights:</strong> the Contracts (Rights of Third Parties) Act 1999 does not apply.</li>
            <li><strong>Notices:</strong> formal notices must be in writing and sent to the contact email above (for us) or the email address you provided in your Order (for you).</li>
            <li><strong>Severability:</strong> if any provision is held invalid, the remainder continues in force.</li>
            <li><strong>Governing law:</strong> these terms are governed by the laws of England and Wales. The courts of England and Wales have exclusive jurisdiction.</li>
          </ul>
        </section>

        <section id="contact">
          <h2>Contact</h2>
          <div class="info-card">
            <div class="info-row"><span class="info-label">Email</span><span class="info-value"><a href="mailto:hello@operationsdirector.co.uk">hello@operationsdirector.co.uk</a></span></div>
          </div>
          <p class="muted">If you have a complaint about our service, please email us first so we can try to resolve it directly.</p>
        </section>

        <div class="back-top"><a href="#" onclick="window.scrollTo({top:0,behavior:'smooth'});return false;">↑ Back to top</a></div>

      </article>
    </div>
  </div>
</main>

<style>
/* === Terms page styling (scoped to .od-page-terms) === */
.od-page-terms a { color: var(--green-700); text-decoration: none; }
.od-page-terms a:hover { color: var(--green-900); text-decoration: underline; }

.legal-hero {
  background: linear-gradient(180deg, var(--sage-50) 0%, var(--bg-app) 100%);
  border-bottom: 1px solid var(--border-subtle);
  padding: 72px 32px 56px;
}
.legal-hero-inner { max-width: 1100px; margin: 0 auto; text-align: left; }
.legal-eyebrow {
  display: inline-block;
  font-size: 12px; font-weight: 600;
  letter-spacing: 0.12em; text-transform: uppercase;
  color: var(--green-700);
  background: var(--green-50);
  padding: 6px 12px;
  border-radius: 999px;
  border: 1px solid var(--green-100);
  margin-bottom: 18px;
}
.legal-hero h1 {
  font-size: clamp(36px, 5vw, 56px);
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.05;
  margin-bottom: 16px;
}
.legal-subtitle {
  font-size: clamp(16px, 1.6vw, 19px);
  color: var(--text-secondary);
  max-width: 720px;
}

.legal-wrap { max-width: 1100px; margin: 0 auto; padding: 56px 32px 80px; }
.legal-grid {
  display: grid;
  grid-template-columns: 260px 1fr;
  gap: 56px;
  align-items: start;
}

.legal-toc { position: sticky; top: 90px; }
.toc-card {
  background: var(--bg-surface);
  border: 1px solid var(--border-subtle);
  border-radius: 14px;
  padding: 22px 20px;
  max-height: calc(100vh - 120px);
  overflow-y: auto;
}
.toc-title {
  font-size: 11px; font-weight: 700;
  letter-spacing: 0.1em; text-transform: uppercase;
  color: var(--text-muted);
  margin-bottom: 14px;
}
.toc-card nav { display: flex; flex-direction: column; gap: 2px; }
.toc-card a {
  font-size: 13.5px;
  color: var(--text-secondary);
  padding: 6px 8px;
  border-radius: 6px;
  border-left: 2px solid transparent;
  transition: all .15s;
}
.toc-card a:hover {
  background: var(--sage-50);
  color: var(--forest-900);
  text-decoration: none;
  border-left-color: var(--green-500);
}
.toc-card a.sub { padding-left: 18px; font-size: 12.5px; color: var(--text-muted); }

.legal-body {
  background: var(--bg-surface);
  border: 1px solid var(--border-subtle);
  border-radius: 16px;
  padding: 48px 56px;
  font-size: 15.5px;
  line-height: 1.6;
}
.legal-body section { margin-bottom: 32px; }
.legal-body h2 {
  font-size: 26px; font-weight: 700;
  letter-spacing: -0.02em;
  margin-bottom: 14px;
  color: var(--forest-900);
}
.legal-body h3 {
  font-size: 18px; font-weight: 700;
  letter-spacing: -0.01em;
  margin-bottom: 10px;
  color: var(--forest-800);
}
.legal-body p { margin-bottom: 12px; color: var(--text-primary); }
.legal-body p.muted { color: var(--text-secondary); font-size: 14.5px; }
.legal-body em { color: var(--text-secondary); font-style: italic; }
.legal-body strong { font-weight: 600; color: var(--forest-900); }
.prose-list { margin: 8px 0 16px 0; padding-left: 22px; }
.prose-list li { margin-bottom: 8px; color: var(--text-primary); }
.prose-list li::marker { color: var(--green-700); }

.part-divider {
  margin: 48px 0 24px;
  padding: 28px 0 20px;
  border-top: 1px solid var(--border-default);
}
.part-tag {
  display: inline-block;
  font-size: 11px; font-weight: 700;
  letter-spacing: 0.14em; text-transform: uppercase;
  color: var(--gold-700);
  background: var(--gold-100);
  border: 1px solid var(--gold-200);
  padding: 5px 11px;
  border-radius: 6px;
  margin-bottom: 12px;
}
.part-heading {
  font-size: 30px !important;
  font-weight: 700;
  letter-spacing: -0.025em;
  margin-bottom: 10px !important;
}
.part-intro { color: var(--text-secondary); font-size: 15px; max-width: 640px; }

.info-card {
  background: var(--sage-50);
  border: 1px solid var(--border-subtle);
  border-radius: 12px;
  padding: 6px 4px;
  margin: 14px 0 16px;
}
.info-row {
  display: grid;
  grid-template-columns: 180px 1fr;
  gap: 14px;
  padding: 10px 18px;
  border-bottom: 1px solid var(--border-subtle);
  font-size: 14.5px;
}
.info-row:last-child { border-bottom: 0; }
.info-label {
  color: var(--text-muted);
  font-weight: 500;
  font-size: 13px;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}
.info-value { color: var(--forest-900); font-weight: 500; }

.callout {
  background: var(--gold-100);
  border: 1px solid var(--gold-200);
  border-left: 3px solid var(--gold-500);
  border-radius: 8px;
  padding: 14px 18px;
  margin: 14px 0 16px;
}
.callout-label {
  font-size: 11px; font-weight: 700;
  letter-spacing: 0.12em; text-transform: uppercase;
  color: var(--gold-700);
  margin-bottom: 6px;
}
.callout p { margin: 0; font-size: 14.5px; color: var(--forest-800); }

.back-top {
  margin-top: 40px;
  padding-top: 24px;
  border-top: 1px solid var(--border-subtle);
  text-align: center;
}
.back-top a {
  display: inline-block;
  padding: 8px 16px;
  font-size: 13px;
  font-weight: 500;
  color: var(--text-secondary);
  border: 1px solid var(--border-default);
  border-radius: 999px;
  background: var(--bg-surface-2, var(--sage-50));
}
.back-top a:hover {
  color: var(--green-700);
  border-color: var(--green-500);
  text-decoration: none;
}

@media (max-width: 960px) {
  .legal-grid { grid-template-columns: 1fr; gap: 24px; }
  .legal-toc { position: static; }
  .toc-card { max-height: none; }
  .legal-body { padding: 32px 28px; }
}
@media (max-width: 640px) {
  .legal-hero { padding: 48px 22px 40px; }
  .legal-wrap { padding: 32px 18px 56px; }
  .legal-body { padding: 26px 22px; font-size: 15px; }
  .info-row { grid-template-columns: 1fr; gap: 4px; padding: 10px 14px; }
}
</style>

<script>
// Highlight current TOC entry on scroll
(function() {
  var tocLinks = document.querySelectorAll('.toc-card nav a');
  var sections = Array.prototype.map.call(tocLinks, function(a) {
    var id = a.getAttribute('href').replace('#','');
    return { id: id, el: document.getElementById(id), link: a };
  }).filter(function(s) { return s.el; });
  if (!sections.length) return;

  function setActive() {
    var y = window.scrollY + 120;
    var current = sections[0];
    sections.forEach(function(s) {
      if (s.el.offsetTop <= y) current = s;
    });
    tocLinks.forEach(function(a) {
      a.style.removeProperty('background');
      a.style.removeProperty('border-left-color');
      a.style.removeProperty('color');
    });
    if (current) {
      current.link.style.background = 'var(--sage-50)';
      current.link.style.borderLeftColor = 'var(--green-500)';
      current.link.style.color = 'var(--forest-900)';
    }
  }
  window.addEventListener('scroll', setActive, { passive: true });
  setActive();
})();
</script>

<?php get_footer(); ?>
