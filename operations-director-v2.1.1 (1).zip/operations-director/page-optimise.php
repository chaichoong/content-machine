<?php
/**
 * Template Name: OPTIMISE Framework
 * Description: The 8-pillar framework page.
 *
 * @package OperationsDirector
 */
get_header();
?>
<main class="od-page-optimise">
  <section class="optimise-hero">
    <div style="display:inline-block; font-size:13px; font-weight:600; color:var(--green-700); margin-bottom:16px;">The framework</div>
    <h1><em>OPTIMISE.</em><br>Eight pillars. One OS.</h1>
    <p>Every Operations Director module is built on the same framework — the sequence we've refined across dozens of SME installations. Order matters, because fixing the wrong thing first costs you twice.</p>
  </section>
  <div class="pillars">
    <div class="pillar"><div class="pillar-letter">O</div><div class="pillar-body"><h3>Organise</h3><p>Map the business as it is. Every process, tool, bottleneck and owner. You can't systemise what you haven't seen clearly.</p></div></div>
    <div class="pillar"><div class="pillar-letter">P</div><div class="pillar-body"><h3>Prioritise</h3><p>Rank every leak by cost and effort. Fix the 20% of problems causing 80% of the damage first.</p></div></div>
    <div class="pillar"><div class="pillar-letter">T</div><div class="pillar-body"><h3>Templatise</h3><p>Turn every recurring decision into a documented SOP. If it happens more than twice, it becomes a template.</p></div></div>
    <div class="pillar"><div class="pillar-letter">I</div><div class="pillar-body"><h3>Integrate</h3><p>Connect the stack. Airtable, Make.com, Slack, Gmail, Claude. One flow of data, not five.</p></div></div>
    <div class="pillar"><div class="pillar-letter">M</div><div class="pillar-body"><h3>Measure</h3><p>Build dashboards that matter. Cash, pipeline, team capacity, compliance. Real numbers, updated live.</p></div></div>
    <div class="pillar"><div class="pillar-letter">I</div><div class="pillar-body"><h3>Improve</h3><p>Weekly check-ins against objectives. What moved, what didn't, what needs fixing this week.</p></div></div>
    <div class="pillar"><div class="pillar-letter">S</div><div class="pillar-body"><h3>Systemise</h3><p>Remove the founder from the workflow wherever possible. Automation first, delegation second, founder decision last.</p></div></div>
    <div class="pillar"><div class="pillar-letter">E</div><div class="pillar-body"><h3>Elevate</h3><p>The founder shifts from operator to owner. Strategy, growth and the next bet — not the day-to-day.</p></div></div>
  </div>

</main>
<?php get_footer(); ?>
