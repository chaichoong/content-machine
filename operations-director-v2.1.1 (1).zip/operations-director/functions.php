<?php
/**
 * Operations Director theme functions
 *
 * Enqueues the compiled CSS/JS, registers menus (optional), localises page URLs
 * for the JS fallback, and sets basic theme supports.
 *
 * @package OperationsDirector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'od_setup' ) ) {
	function od_setup() {
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption' ) );
		add_theme_support( 'custom-logo' );
		// Allow Kevin to override the favicon via Appearance > Customize > Site Identity
		add_theme_support( 'site-icon' );
	}
}
add_action( 'after_setup_theme', 'od_setup' );

if ( ! function_exists( 'od_enqueue_assets' ) ) {
	function od_enqueue_assets() {
		$theme_version = wp_get_theme()->get( 'Version' );

		// Google Fonts
		wp_enqueue_style(
			'od-google-fonts',
			'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&display=swap',
			array(),
			null
		);

		// Main stylesheet
		wp_enqueue_style(
			'od-main',
			get_template_directory_uri() . '/assets/css/main.css',
			array( 'od-google-fonts' ),
			$theme_version
		);

		// Main JS (modules, modals, mega nav)
		wp_enqueue_script(
			'od-main',
			get_template_directory_uri() . '/assets/js/main.js',
			array(),
			$theme_version,
			true
		);

		// Expose real WordPress page URLs to JS (for showPage fallback)
		wp_localize_script(
			'od-main',
			'OD_PAGES',
			array(
				'home'     => home_url( '/' ),
				'about'    => home_url( '/about/' ),
				'optimise' => home_url( '/optimise/' ),
				'faq'      => home_url( '/faq/' ),
				'terms'    => home_url( '/terms/' ),
				'privacy'  => home_url( '/terms/#part-c' ),
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'od_enqueue_assets' );

/**
 * Register nav menus (optional — nav is currently hardcoded to match the design).
 * Left in for future use if Kevin wants to make the nav editable from WP admin.
 */
if ( ! function_exists( 'od_register_menus' ) ) {
	function od_register_menus() {
		register_nav_menus(
			array(
				'primary' => __( 'Primary Navigation', 'operations-director' ),
				'footer'  => __( 'Footer Navigation', 'operations-director' ),
			)
		);
	}
}
add_action( 'after_setup_theme', 'od_register_menus' );

/**
 * Auto-create the standard set of pages on theme activation.
 *
 * Creates page records for: Home, About, Optimisation, FAQ, Terms.
 * Each is wired to its corresponding template (via _wp_page_template meta)
 * and given a fixed slug so footer/nav links resolve correctly.
 *
 * Idempotent: checks for an existing page at the slug FIRST. If you've already
 * manually created a page with that slug, this function leaves it alone — it
 * never overwrites existing content. Safe to re-run.
 *
 * Also configures the static front page so / renders front-page.php (Home).
 */
if ( ! function_exists( 'od_create_default_pages' ) ) {
	function od_create_default_pages() {

		$pages = array(
			'home' => array(
				'title'    => 'Home',
				'template' => '', // front-page.php is automatic when set as static front page
			),
			'about' => array(
				'title'    => 'About',
				'template' => 'page-about.php',
			),
			'optimise' => array(
				'title'    => 'OPTIMISE Framework',
				'template' => 'page-optimise.php',
			),
			'faq' => array(
				'title'    => 'FAQ',
				'template' => 'page-faq.php',
			),
			'terms' => array(
				'title'    => 'Terms',
				'template' => 'page-terms.php',
			),
		);

		$created_ids = array();

		foreach ( $pages as $slug => $info ) {
			// Skip if a page with this slug already exists (any status)
			$existing = get_page_by_path( $slug, OBJECT, 'page' );
			if ( $existing ) {
				$created_ids[ $slug ] = $existing->ID;
				continue;
			}

			$page_id = wp_insert_post(
				array(
					'post_title'     => $info['title'],
					'post_name'      => $slug,
					'post_status'    => 'publish',
					'post_type'      => 'page',
					'post_content'   => '', // templates provide all content
					'comment_status' => 'closed',
					'ping_status'    => 'closed',
				),
				true
			);

			if ( ! is_wp_error( $page_id ) && $page_id ) {
				if ( ! empty( $info['template'] ) ) {
					update_post_meta( $page_id, '_wp_page_template', $info['template'] );
				}
				$created_ids[ $slug ] = $page_id;
			}
		}

		// Set static front page = Home, so front-page.php renders at /
		if ( ! empty( $created_ids['home'] ) && 'page' !== get_option( 'show_on_front' ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $created_ids['home'] );
		} elseif ( ! empty( $created_ids['home'] ) ) {
			$current_front = (int) get_option( 'page_on_front' );
			if ( ! $current_front || ! get_post( $current_front ) ) {
				update_option( 'page_on_front', $created_ids['home'] );
			}
		}

		// Flush rewrite rules so the new slugs resolve immediately
		flush_rewrite_rules( false );
	}
}
add_action( 'after_switch_theme', 'od_create_default_pages' );

/**
 * Admin-side safety net.
 *
 * If the pages weren't created on theme activation (e.g. theme uploaded
 * without proper deactivation/reactivation), re-run the auto-create when
 * an admin loads any admin screen. Stores a per-version flag so it only
 * runs once per theme version, not on every admin page load.
 */
if ( ! function_exists( 'od_ensure_default_pages' ) ) {
	function od_ensure_default_pages() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$version = wp_get_theme()->get( 'Version' );
		if ( get_option( 'od_pages_created_v' ) === $version ) {
			return;
		}
		od_create_default_pages();
		update_option( 'od_pages_created_v', $version );
	}
}
add_action( 'admin_init', 'od_ensure_default_pages' );

