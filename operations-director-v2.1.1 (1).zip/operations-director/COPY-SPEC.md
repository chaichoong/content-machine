# Operations Director — Locked Copy Spec for Erica

**Version:** 2.0 (single-offer launch)
**Locked by:** Kevin Brittain
**Last updated:** 28 April 2026

---

## The single source of truth

This is the only copy that goes live. Do not deviate. Do not add testimonials we don't have. Do not invent stats. If something is missing here, ask before writing.

---

## The offer (one only)

- **Implementation:** £1,997 one-off
- **Subscription:** £247/month, starts month 4
- **Minimum term:** 12 months
- **Delivery time:** 90 days from kick-off to live
- **Booking link (every CTA goes here):** https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0
- **No self-serve checkout. No Stripe on the site at launch.**
- **No equity option at launch.** (Decision logged.)
- **No tiers.** No Solo/Team/Full OS. No £49/£149/£299. Strip on sight.

---

## Brand voice rules

- UK English, direct, no fluff.
- No em dashes. Use full stops or colons instead.
- No motivational language. No "transform your business". No "unlock your potential".
- No emoji.
- No exclamation marks.
- Sentences short. Paragraphs short.
- "We" build it. The customer doesn't have to learn it.
- Never say "AI-powered" as a marketing buzzword. Say what the AI does.

---

## Headline copy (locked)

### Hero
- **Eyebrow:** Done-for-you Operations OS for UK SMEs
- **H1:** Your business runs on you. That's the problem.
- **Sub:** We build the operating system your business should already have. One implementation, one monthly subscription, one place everything runs from. So the business runs without you watching it.
- **Primary CTA:** Book a conversation
- **Secondary CTA:** How it works (scrolls to How section)

### Who this is for
Founder-led businesses, £100k+ turnover, 1–20 staff, where everything still depends on you.

### What's inside (modules section header)
- **Title:** What's inside the operating system
- **Sub:** Ten connected modules covering the parts of the business that usually break first. Built around how you actually work — not generic templates.

(Modules render from JS. Each card shows category, name, description, and an "Included" pill. No per-module pricing.)

### Why this works (4 bento cards)

**Card 1 — One operating system, not five disconnected tools.**
Airtable as the source of truth. Make.com for automation. Claude as the AI layer. Slack as your command centre. All wired up. All documented. All yours.

**Card 2 — AI does the work, not just the chatting.**
Claude handles triage, drafting, reconciliation and routing in the background. Your team doesn't have to. Not a chatbot bolted on the side.

**Card 3 — Implemented in 90 days, not 12 months.**
Three months of build. Then it runs. We don't sell consulting workshops or strategy decks. We build the system, deliver it, and support it.

**Card 4 — You own it. No lock-in.**
The system lives inside your Airtable, your Make.com, your Slack. Cancel any time and the operating system keeps running. The updates and support stop. The infrastructure stays.

### How it works (3 steps)

**1 — Conversation**
30 minutes. We look at your business, your numbers, where it's leaking time and money. If it's a fit, we book the start date. If it's not, we tell you.

**2 — Implementation (months 1–3)**
We build the operating system around your actual business. Data model, automations, SOPs, dashboards. You're involved as much or as little as you want.

**3 — Run it (month 4 onwards)**
System goes live. £247/month covers ongoing support, updates and refinements. The business runs without you watching it.

### Pricing

- **Tier name:** Operations OS
- **Tagline:** For founder-led businesses ready to take themselves out of the middle
- **Price display:** £1,997 (one-off implementation)
- **Sub line:** Then £247/month from month 4 · Minimum 12 months
- **Features list:**
  - Full operating system built around your business
  - Airtable + Make.com + Slack + Claude AI layer
  - Data model, automations, SOPs and dashboards
  - End-to-end implementation over 90 days
  - Ongoing support, updates and refinements
  - You own everything. No lock-in.
- **CTA:** Book a conversation
- **Footnote:** VAT applied where applicable. We'll discuss terms on the call.

### Is this a fit?

**You'll get value if**
You turn over £100k+, have 1–20 staff, and the business stops working when you take a week off. You've tried tools. You don't want another one.

**You won't if**
You want strategy advice, a coach, or someone to tell you what to do. We don't coach. We build.

**What happens next**
30-minute conversation. We look at your numbers and how the business runs today. No pressure. No pitch. Just a proper discussion.

### Final CTA
- **H2:** Stop running the business in your head.
- **Sub:** Book a 30-minute conversation. We'll look at your business, your numbers, and whether this is a fit.
- **CTA:** Book a conversation

---

## What to strip from existing site

If any of these appear anywhere on the WordPress build, remove them:

- £49/mo, £149/mo, £299/mo — any of these prices
- "Solo", "Team", "Full OS" tier names
- "Marketplace" as a product positioning (it's a list of modules, not a marketplace)
- "Buy a module" / "Install a module" buttons that aren't gated by Book a Call
- "Get the OS" CTA — replace with "Book a conversation"
- "Enterprise offering coming soon" alert button
- Any reference to "47 minutes" install time — the real number is 90 days
- Any per-module price displayed on cards or in the modal

---

## CTAs — the only acceptable buttons

Every CTA on the site goes to the same GHL booking link. There are no exceptions until self-serve checkout is added in Phase 3.

- "Book a conversation" — primary
- "How it works" — secondary, scrolls to #how on the home page
- Module card buttons — open modal, then modal CTA is "Book a conversation"

---

## What's NOT on the launch site

Do not add any of the following without Kevin's explicit sign-off:

- Testimonials (we have none yet)
- Case studies (none yet)
- Logos of clients (none yet)
- "Trusted by" sections
- Lead magnets or email capture forms (Phase 2 only)
- Live chat widgets
- Cookie banners (handled separately if needed)
- Stripe payment buttons
- "Enterprise" tier
- Equity option page
- Blog / Founder log / Community / SOP library (all marked "coming soon" in nav, leave them as-is)

---

## Pages that exist

- **Home** (slug: `home`, template: Default) — single-offer landing page above
- **About** (slug: `about`, template: About) — leave as-is
- **OPTIMISE** (slug: `optimise`, template: OPTIMISE Framework) — leave as-is
- **FAQ** (slug: `faq`, template: FAQ) — review FAQ answers for old pricing references and update to match £1,997 + £247

---

## FAQ updates needed

Audit FAQ page (`page-faq.php`) for any of these phrases and update:
- Mentions of "£49", "Solo tier", "Team tier", "Full OS"
- "Cancel anytime" claims that conflict with 12-month minimum
- "Buy a module" — change to "Book a conversation"

If you find anything, log it and ask Kevin before changing.

---

## Booking link — single source

`https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0`

If this changes, all CTAs on every page need updating in one go. Search the theme for the string and replace.

---

## Approval gate

Before pushing live, confirm with Kevin:
1. Homepage looks right on mobile (test 375px width)
2. Every CTA opens the booking link in a new tab
3. No old pricing visible anywhere
4. FAQ page reviewed and updated
5. Modal CTA goes to booking link, not an "Install module" button
