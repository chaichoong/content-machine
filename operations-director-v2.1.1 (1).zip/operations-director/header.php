<?php
/**
 * Header template — includes the DOCTYPE, <head>, opening <body>, and site nav.
 *
 * @package OperationsDirector
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

	<?php /* Favicons */ ?>
	<link rel="icon" type="image/x-icon" href="<?php echo esc_url( get_template_directory_uri() . '/assets/img/favicon.ico' ); ?>">
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo esc_url( get_template_directory_uri() . '/assets/img/favicon-16x16.png' ); ?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url( get_template_directory_uri() . '/assets/img/favicon-32x32.png' ); ?>">
	<link rel="icon" type="image/png" sizes="48x48" href="<?php echo esc_url( get_template_directory_uri() . '/assets/img/favicon-48x48.png' ); ?>">
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( get_template_directory_uri() . '/assets/img/apple-touch-icon.png' ); ?>">
	<link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url( get_template_directory_uri() . '/assets/img/android-chrome-192x192.png' ); ?>">
	<link rel="icon" type="image/png" sizes="512x512" href="<?php echo esc_url( get_template_directory_uri() . '/assets/img/android-chrome-512x512.png' ); ?>">
	<meta name="theme-color" content="#2C6E49">

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<nav class="nav">
  <div class="nav-inner">
    <a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" style="text-decoration:none;">
      <div class="logo-mark">
        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo.png' ); ?>" alt="Operations Director" width="32" height="32"/>
      </div>
      Operations Director
    </a>

    <ul class="nav-links" id="navLinks">
      <li><a class="nav-top" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
      <li><a class="nav-top" href="<?php echo esc_url( home_url( '/about/' ) ); ?>">About</a></li>
      <li><a class="nav-top" href="<?php echo esc_url( home_url( '/optimise/' ) ); ?>">Optimisation</a></li>
      <li><a class="nav-top" href="<?php echo esc_url( home_url( '/faq/' ) ); ?>">FAQ</a></li>
      <li><a class="nav-top" href="<?php echo esc_url( home_url( '/#pricing' ) ); ?>">Pricing</a></li>
    </ul>

    <a class="nav-cta" href="https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0" target="_blank" rel="noopener">Book a conversation →</a>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
  </div>
</nav>

