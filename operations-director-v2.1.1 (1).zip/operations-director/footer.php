
<div class="modal-overlay" id="modalOverlay" onclick="closeModalBg(event)">
  <div class="modal">
    <button class="modal-close" onclick="closeModal()">×</button>
    <div class="modal-hero">
      <div class="modal-hero-content">
        <div class="modal-icon" id="modalIcon"></div>
        <div class="modal-hero-text">
          <div class="modal-cat" id="modalCat">Leadership</div>
          <h3 id="modalTitle">Leadership Dashboard OS</h3>
        </div>
      </div>
    </div>
    <div class="modal-body">
      <p class="modal-tagline" id="modalTagline"></p>
      <div class="modal-section-title">What's inside</div>
      <ul class="modal-list" id="modalFeatures"></ul>
      <div class="modal-section-title">Works with</div>
      <ul class="modal-list" id="modalIntegrations"></ul>
    </div>
    <div class="modal-footer">
      <div class="modal-price">
        <div class="modal-price-num">Included</div>
        <div class="modal-price-unit">part of the full Operations OS</div>
      </div>
      <div class="modal-actions">
        <button class="btn-secondary" onclick="closeModal()">Close</button>
        <a class="btn-primary" href="https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0" target="_blank" rel="noopener">Book a conversation <span class="arrow">→</span></a>
      </div>
    </div>
  </div>
</div>


<footer>
  <div class="footer-inner">
    <div class="footer-brand">
      <div class="logo">
        <div class="logo-mark">
          <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo-footer.png' ); ?>" alt="Operations Director" width="32" height="32"/>
        </div>
        Operations Director
      </div>
      <p>Done-for-you operating systems for UK SMEs. We build the system your business should already have. So the business runs without you.</p>
    </div>
    <div class="footer-col">
      <h5>Product</h5>
      <ul>
        <li><a href="<?php echo esc_url( home_url( '/#features' ) ); ?>">What's included</a></li>
        <li><a href="<?php echo esc_url( home_url( '/#pricing' ) ); ?>">Pricing</a></li>
        <li><a href="<?php echo esc_url( home_url( '/optimise/' ) ); ?>">OPTIMISE Framework</a></li>
        <li><a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>">FAQ</a></li>
        <li><a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>">Terms &amp; Conditions</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h5>Modules</h5>
      <ul>
        <li><button onclick="openModule('leadership')"><span class="fc-ic"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3h7v9H3z"/><path d="M14 3h7v5h-7z"/><path d="M14 12h7v9h-7z"/><path d="M3 16h7v5H3z"/></svg></span> Leadership OS</button></li>
        <li><button onclick="openModule('pl')"><span class="fc-ic"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2"/><path d="M6 12h.01M18 12h.01"/></svg></span> Profit & Loss OS</button></li>
        <li><button onclick="openModule('objectives')"><span class="fc-ic"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg></span> Objectives OS</button></li>
        <li><button onclick="openModule('compliance')"><span class="fc-ic"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg></span> Compliance OS</button></li>
      </ul>
    </div>
    <div class="footer-col">
      <h5>Legal</h5>
      <ul>
        <li><a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>">Terms &amp; Conditions</a></li>
        <li><a href="<?php echo esc_url( home_url( '/terms/#part-c' ) ); ?>">Privacy</a></li>
        <li><a href="<?php echo esc_url( home_url( '/terms/#part-a' ) ); ?>">Website Terms of Use</a></li>
        <li><a href="<?php echo esc_url( home_url( '/terms/#part-b' ) ); ?>">Service Agreement</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h5>Company</h5>
      <ul>
        <li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">About</a></li>
        <li><a href="https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0" target="_blank" rel="noopener">Book a conversation</a></li>
        <li><a href="mailto:hello@operationsdirector.co.uk">hello@operationsdirector.co.uk</a></li>
        <li><span>Cambridge, UK</span></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <div>&copy; <?php echo esc_html( date( 'Y' ) ); ?> Operations Director Ltd. All rights reserved. &middot; <a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>" style="color:inherit;text-decoration:underline;">Terms</a> &middot; <a href="<?php echo esc_url( home_url( '/terms/#part-c' ) ); ?>" style="color:inherit;text-decoration:underline;">Privacy</a></div>
    <div>Built by founders, for founders.</div>
  </div>
</footer>


<?php wp_footer(); ?>
</body>
</html>
