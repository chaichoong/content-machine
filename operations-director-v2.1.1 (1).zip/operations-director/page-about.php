<?php
/**
 * Template Name: About
 * Description: About Kevin page — founder story.
 *
 * @package OperationsDirector
 */
get_header();
?>
<main class="od-page-about">
  <section class="about-hero">
    <h1>I built Operations Director <em>because I lived the problem.</em></h1>
    <p>From founder-dependent to founder-optional, in one infrastructure rebuild.</p>
  </section>
  <article class="story">
    <p class="lead">I run a property portfolio across Cambridge, Haverhill, Burnley, Manchester and Hamilton. I founded Runpreneur, a children's charity mission funded by a daily running streak and two Guinness World Records. And for years, I ran everything out of my head, a phone, and twenty-three browser tabs.</p>
    <p>It worked until it didn't.</p>
    <p>The business grew. The admin grew faster. I was making decisions at 11pm that should have been made by systems at 9am. The team was capable but blocked — every question routed back to me. I was the bottleneck dressed up as the boss.</p>
    <p>So I rebuilt the entire operation from the ground up. Airtable as the single source of truth. Make.com for automation. Claude as the AI layer. Slack as the command centre. SOPs for every recurring task. Dashboards for every KPI that mattered.</p>
    <div class="story-pull">"The portfolio runs without me watching it. Cash flow is visible 30 days out, not 30 days late."</div>
    <p>And I get to run — every day, without fail — because the business doesn't need me to hold it up anymore.</p>
    <p>Operations Director is that same infrastructure, packaged as modules any UK SME can install. Not templates. Not courses. Working operating systems built from a business that actually uses them every day.</p>
    <p class="lead">If you're the bottleneck in your own business, I've been there. I know the way out.</p>
  </article>
  <section class="cred-band">
    <div class="cred-inner">
      <div class="cred">
        <div class="cred-num">2×</div>
        <div class="cred-label">Guinness World Records in endurance running</div>
      </div>
      <div class="cred">
        <div class="cred-num">1,600+</div>
        <div class="cred-label">Consecutive days of a running streak</div>
      </div>
      <div class="cred">
        <div class="cred-num">£2m</div>
        <div class="cred-label">Fundraising mission for children's charities</div>
      </div>
      <div class="cred">
        <div class="cred-num">5</div>
        <div class="cred-label">UK cities hosting the property portfolio</div>
      </div>
    </div>
  </section>

</main>
<?php get_footer(); ?>
