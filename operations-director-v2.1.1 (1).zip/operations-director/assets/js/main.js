const modules = [
  {
    id: 'leadership', category: 'leadership', categoryLabel: 'Leadership', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3h7v9H3z"/><path d="M14 3h7v5h-7z"/><path d="M14 12h7v9h-7z"/><path d="M3 16h7v5H3z"/></svg>',
    title: 'Leadership Dashboard OS',
    desc: 'Live financial + operational metrics on a single dashboard.',
    tagline: 'The command centre view. Live cash flow forecast, portfolio metrics, AI commentary and balance calculator — all refreshing every 15 minutes.',
    features: ['31-day cash flow forecast', 'Balance calculator', 'AI analysis + commentary', 'Portfolio overview', 'Tenancy metrics', 'Financial KPIs'],
    integrations: ['Airtable', 'Fintable bank sync', 'Claude AI', 'Slack'],
    price: '', badge: 'Popular', variant: ''
  },
  {
    id: 'objectives', category: 'leadership', categoryLabel: 'Leadership', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
    title: 'Objective & Strategy OS',
    desc: 'Quarterly objectives, KPIs and team accountability.',
    tagline: 'Turn strategy into weekly execution. Set objectives, cascade to tasks, track KPIs, and run check-ins that move the needle.',
    features: ['Quarterly objective tracker', 'KPI dashboards', 'Weekly check-in automation', 'Goal → task cascade', '1:1 notes', 'Performance reviews'],
    integrations: ['Airtable', 'Slack', 'Google Calendar'],
    price: '', badge: 'New', variant: 'variant-3'
  },
  {
    id: 'pl', category: 'finance', categoryLabel: 'Finance', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2"/><path d="M6 12h.01M18 12h.01"/></svg>',
    title: 'Profit & Loss OS',
    desc: 'Real-time P&L with auto-categorised transactions.',
    tagline: 'Live profit and loss statement, updated with every transaction. Know your position daily, not quarterly.',
    features: ['Real-time P&L', 'Auto-categorised transactions', 'Gross margin tracking', 'Business-level breakdown', 'Monthly comparisons', 'Export to Xero / QBO'],
    integrations: ['Xero', 'QuickBooks', 'Stripe', 'Fintable'],
    price: '', badge: 'Gold', variant: 'variant-4'
  },
  {
    id: 'cashflow', category: 'finance', categoryLabel: 'Finance', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>',
    title: 'Cash Flow Voids OS',
    desc: 'Auto-detected void tenancies and overdue rent alerts.',
    tagline: 'Never miss a rent void. Auto-detects overdue payments with 2-day tolerance and triggers chase actions by contact preference.',
    features: ['Void tenancy detection', 'Overdue rent tracking', 'Automated chase sequences', 'Contact preference routing', 'Days-overdue counter', 'Resolution tracking'],
    integrations: ['Airtable', 'Fintable', 'Gmail', 'Slack'],
    price: '', badge: '', variant: 'variant-2'
  },
  {
    id: 'invoices', category: 'finance', categoryLabel: 'Finance', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 17.5v-11"/></svg>',
    title: 'Invoices OS',
    desc: 'Gmail-integrated invoice-to-pay workflow.',
    tagline: 'Every invoice labelled "to pay" in Gmail, pulled into one sortable, filterable workflow. Approve, pay, archive.',
    features: ['Gmail label sync', 'Sort by date/amount/payee', 'Batch approval', 'Payment tracking', 'Historical search', 'Vendor management'],
    integrations: ['Gmail', 'Airtable', 'Xero', 'Stripe'],
    price: '', badge: '', variant: ''
  },
  {
    id: 'tasks', category: 'operations', categoryLabel: 'Operations', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 11 3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>',
    title: 'Task & Project Management OS',
    desc: 'Task routing, SOPs and team execution on autopilot.',
    tagline: 'The operational backbone. Every recurring task documented, assigned, and tracked — without the founder touching it.',
    features: ['SOP library', 'Task routing via Slack', 'Recurring scheduler', 'Team workload view', 'Approval workflows', 'Status dashboards'],
    integrations: ['Airtable', 'Slack', 'Make.com', 'Google Workspace'],
    price: '', badge: 'Foundational', variant: 'variant-5'
  },
  {
    id: 'contractor', category: 'operations', categoryLabel: 'Operations', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
    title: 'Contractor Job List OS',
    desc: 'Contractor briefs, job tracking and completion sign-off.',
    tagline: 'Every contractor job briefed, tracked, and signed off. From initial request to completed invoice.',
    features: ['Job creation workflow', 'Contractor assignment', 'Photo + video briefs', 'Progress tracking', 'Completion sign-off', 'Invoice matching'],
    integrations: ['Airtable', 'Slack', 'WhatsApp', 'Gmail'],
    price: '', badge: '', variant: 'variant-6'
  },
  {
    id: 'comms', category: 'comms', categoryLabel: 'Communications', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>',
    title: 'Inbound Comms OS',
    desc: 'AI-triaged email, call and message handling.',
    tagline: 'Turn inbound chaos into a clean workflow. Claude triages, classifies and routes every message to the right person or process.',
    features: ['AI email triage', 'Call logging', 'Message routing', 'Response tracking', 'SLA monitoring', 'Team inbox views'],
    integrations: ['Gmail', 'GoHighLevel', 'Slack', 'WhatsApp Business'],
    price: '', badge: '', variant: 'variant-3'
  },
  {
    id: 'compliance', category: 'compliance', categoryLabel: 'Compliance', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>',
    title: 'Property Compliance OS',
    desc: 'Certificates, renewals and regulatory deadlines tracked.',
    tagline: 'Never miss a renewal. Every EICR, gas safety, insurance and licence tracked with alerts at 30, 14 and 7 days out.',
    features: ['Certificate expiry tracker', 'Automated renewal alerts', 'HMO licence tracking', 'Gas + EICR management', 'Document vault', 'Audit trail'],
    integrations: ['Google Drive', 'Slack', 'Gmail'],
    price: '', badge: '', variant: 'variant-2'
  },
  {
    id: 'launch', category: 'launch', categoryLabel: 'Launch', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>',
    title: 'OD Launch Plan OS',
    desc: 'Business launch roadmap with milestones and owners.',
    tagline: 'The blueprint for launching a new business unit. Every milestone mapped, every owner assigned, every dependency tracked.',
    features: ['Launch milestone tracker', 'Owner assignment', 'Dependency mapping', 'Go/no-go criteria', 'Weekly status', 'Risk register'],
    integrations: ['Airtable', 'Slack', 'Google Workspace'],
    price: '', badge: 'Blue', variant: 'variant-5'
  }
];

function badgeClass(label) {
  if (!label) return '';
  if (label === 'Gold') return ' gold';
  if (label === 'Blue') return ' blue';
  return '';
}

function renderModules(filter = 'all') {
  const grid = document.getElementById('moduleGrid');
  if (!grid) return;
  const filtered = filter === 'all' ? modules : modules.filter(m => m.category === filter);
  grid.innerHTML = filtered.map(m => `
    <button class="module-card ${m.variant}" onclick="openModule('${m.id}')">
      <div class="module-preview">
        <div class="module-icon">${m.icon}</div>
      </div>
      <div class="module-body">
        <div class="module-cat">${m.categoryLabel}</div>
        <h3>${m.title}</h3>
        <p class="module-desc">${m.desc}</p>
        <div class="module-footer">
          <div class="module-price-included">Included</div>
          ${m.badge ? `<div class="module-badge${badgeClass(m.badge)}">${m.badge === 'Gold' || m.badge === 'Blue' ? (m.badge === 'Gold' ? 'Premium' : 'Featured') : m.badge}</div>` : ''}
        </div>
      </div>
    </button>
  `).join('');
  const countEl = document.getElementById('moduleCount');
  if (countEl) countEl.textContent = filtered.length + ' module' + (filtered.length === 1 ? '' : 's');
  const titleEl = document.getElementById('marketplaceTitle');
  if (titleEl) titleEl.textContent = filter === 'all' ? 'All modules' : modules.find(m => m.category === filter).categoryLabel + ' modules';
}

function openModule(id) {
  const m = modules.find(x => x.id === id);
  if (!m) return;
  document.getElementById('modalIcon').innerHTML = m.icon;
  document.getElementById('modalCat').textContent = m.categoryLabel;
  document.getElementById('modalTitle').textContent = m.title;
  document.getElementById('modalTagline').textContent = m.tagline;
  document.getElementById('modalFeatures').innerHTML = m.features.map(f => `<li>${f}</li>`).join('');
  document.getElementById('modalIntegrations').innerHTML = m.integrations.map(i => `<li>${i}</li>`).join('');
  document.getElementById('modalOverlay').classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('active');
  document.body.style.overflow = '';
}
function closeModalBg(e) { if (e.target.id === 'modalOverlay') closeModal(); }

// WordPress navigation: pages are real URLs now
// OD_PAGES is localised from PHP (see functions.php)
function showPage(pageId) {
  const map = (window.OD_PAGES || {});
  const url = map[pageId] || map.home || '/';
  window.location.href = url;
}

function scrollToId(id) {
  const el = document.getElementById(id);
  if (el) {
    el.scrollIntoView({ behavior: 'smooth' });
  } else {
    // Section not on this page: go home with hash
    const home = (window.OD_PAGES && window.OD_PAGES.home) || '/';
    window.location.href = home + '#' + id;
  }
}

// On load: if URL has a hash, scroll to it smoothly after render
window.addEventListener('load', () => {
  if (window.location.hash) {
    const el = document.getElementById(window.location.hash.substring(1));
    if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth' }), 50);
  }
});

function toggleFaq(el) { el.classList.toggle('open'); }
function toggleMenu() { document.getElementById('navLinks').classList.toggle('mobile-open'); }

document.querySelectorAll('.cat-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    renderModules(chip.dataset.cat);
    document.getElementById('marketplace').scrollIntoView({ behavior: 'smooth' });
  });
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});

// === MEGA NAV ===
const megaItems = document.querySelectorAll('.has-mega');
const megaPanels = document.querySelectorAll('.mega-panel');
let megaCloseTimer = null;

function openMega(name) {
  clearTimeout(megaCloseTimer);
  megaItems.forEach(li => li.classList.toggle('active', li.dataset.mega === name));
  megaPanels.forEach(p => p.classList.toggle('active', p.dataset.panel === name));
}
function closeMega() {
  megaItems.forEach(li => li.classList.remove('active'));
  megaPanels.forEach(p => p.classList.remove('active'));
}
function scheduleClose() {
  clearTimeout(megaCloseTimer);
  megaCloseTimer = setTimeout(closeMega, 180);
}

megaItems.forEach(li => {
  const name = li.dataset.mega;
  li.addEventListener('mouseenter', () => openMega(name));
  li.addEventListener('mouseleave', scheduleClose);
  li.querySelector('.nav-top').addEventListener('click', e => {
    e.stopPropagation();

    // On mobile (<=960px) the mega panels are hidden via CSS.
    // Redirect to a sensible destination instead of doing nothing.
    const isMobile = window.matchMedia('(max-width: 960px)').matches;
    if (isMobile) {
      const map = (window.OD_PAGES || {});
      const home = map.home || '/';
      const targets = {
        product:   home,                    // marketplace lives on home
        ai:        home + '#features',
        solutions: home + '#pricing',
        resources: map.optimise || home
      };
      window.location.href = targets[name] || home;
      return;
    }

    const isOpen = li.classList.contains('active');
    closeMega();
    if (!isOpen) openMega(name);
  });
});
megaPanels.forEach(p => {
  p.addEventListener('mouseenter', () => clearTimeout(megaCloseTimer));
  p.addEventListener('mouseleave', scheduleClose);
});
document.addEventListener('click', e => {
  if (!e.target.closest('.has-mega') && !e.target.closest('.mega-panel')) closeMega();
});

if (document.getElementById('moduleGrid')) {
  renderModules();
}
