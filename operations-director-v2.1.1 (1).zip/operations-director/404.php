<?php
/**
 * 404 template.
 *
 * @package OperationsDirector
 */
get_header();
?>
<main class="od-page-404">
	<section class="about-hero">
		<h1>Page not found.</h1>
		<p>That URL doesn't exist. <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Head back home</a>.</p>
	</section>
</main>
<?php get_footer(); ?>
