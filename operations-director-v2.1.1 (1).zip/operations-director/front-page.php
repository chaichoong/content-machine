<?php
/**
 * Home page template — single offer (£1,997 + £247/mo), Book a Call funnel.
 *
 * @package OperationsDirector
 */
get_header();
?>
<main class="od-page-home">

  <!-- HERO -->
  <section class="hero">
    <div class="hero-grid">
      <div>
        <div class="eyebrow">Done-for-you Operations OS for UK SMEs</div>
        <h1>Your business runs on <span class="highlight">you</span>.<br>That's the problem.</h1>
        <p class="hero-sub">We build the operating system your business should already have. One implementation, one monthly subscription, one place everything runs from. So the business runs without you watching it.</p>
        <div class="hero-actions">
          <a class="btn-primary" href="https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0" target="_blank" rel="noopener">Book a conversation <span class="arrow">→</span></a>
          <button class="btn-secondary" onclick="scrollToId('how')">How it works</button>
        </div>
        <div class="hero-trust">
          <span><strong>For founder-led businesses</strong> with £100k+ turnover</span>
          <span class="dot"></span>
          <span>Built around how you actually work</span>
        </div>
      </div>
      <div class="hero-visual">
        <div class="stat-card c1">
          <div class="stat-label">Cash flow issues</div>
          <div class="stat-number">82%</div>
          <div class="stat-desc">of UK SMEs fail from cash flow problems they saw coming.</div>
        </div>
        <div class="stat-card c2">
          <div class="stat-label">Running blind</div>
          <div class="stat-number">83%</div>
          <div class="stat-desc">are operating without documented systems.</div>
        </div>
        <div class="stat-card c3">
          <div class="stat-label">Weekly time lost</div>
          <div class="stat-number">13.7<span class="unit">hrs</span></div>
          <div class="stat-desc">burned every week tool-hopping. 712 hours a year.</div>
        </div>
      </div>
    </div>
  </section>

  <!-- WHO IT'S FOR -->
  <section class="cat-section">
    <div class="cat-inner cat-inner-centered">
      <div class="cat-label">Who this is for</div>
      <p class="cat-blurb">Founder-led businesses, £100k+ turnover, 1–20 staff, where everything still depends on you.</p>
    </div>
  </section>

  <!-- WHAT'S INCLUDED -->
  <section class="marketplace" id="whats-included">
    <div class="marketplace-header">
      <div>
        <div class="marketplace-title">What's inside the operating system</div>
        <div class="marketplace-sub">Ten connected modules covering the parts of the business that usually break first. Built around how you actually work — not generic templates.</div>
      </div>
    </div>
    <div class="module-grid" id="moduleGrid"></div>
  </section>

  <!-- WHY IT WORKS -->
  <section class="features">
    <div class="features-inner">
      <div class="section-head">
        <div class="eyebrow">Why this works</div>
        <h2>The tools you've bought <em>haven't fixed the problem.</em></h2>
        <p>Because software alone isn't a system. We build a working OS — data model, automations, SOPs, dashboards. Wired together. Working from day one. Designed around your business, not a template.</p>
      </div>
      <div class="bento">
        <div class="bento-card b1">
          <h4>One operating system, <em>not five disconnected tools.</em></h4>
          <p>Airtable as the source of truth. Make.com for automation. Claude as the AI layer. Slack as your command centre. All wired up. All documented. All yours.</p>
          <div class="bento-visual">
            <div class="mock-bars">
              <div class="mock-bar" style="height: 40%"></div>
              <div class="mock-bar" style="height: 65%"></div>
              <div class="mock-bar" style="height: 55%"></div>
              <div class="mock-bar" style="height: 80%"></div>
              <div class="mock-bar" style="height: 70%"></div>
              <div class="mock-bar" style="height: 90%"></div>
              <div class="mock-bar" style="height: 75%"></div>
              <div class="mock-bar" style="height: 95%"></div>
            </div>
          </div>
        </div>
        <div class="bento-card b2">
          <h4>AI does the work, <em>not just the chatting.</em></h4>
          <p>Claude handles triage, drafting, reconciliation and routing in the background. Your team doesn't have to. Not a chatbot bolted on the side.</p>
          <div class="bento-visual">
            <div class="mock-flow">
              <div class="mock-node"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="10" x="3" y="11" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><line x1="8" x2="8" y1="16" y2="16"/><line x1="16" x2="16" y1="16" y2="16"/></svg></div>
              <div class="mock-line"></div>
              <div class="mock-node alt"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg></div>
            </div>
          </div>
        </div>
        <div class="bento-card b3">
          <h4>Implemented <em>in 90 days,</em> not 12 months.</h4>
          <p>Three months of build. Then it runs. We don't sell consulting workshops or strategy decks. We build the system, deliver it, and support it.</p>
          <div class="bento-visual">
            <div class="mock-terminal">
              <div><span class="tok-dim">$</span> <span class="tok-green">build</span> operations-os</div>
              <div><span class="tok-green">✓</span> Airtable base configured</div>
              <div><span class="tok-green">✓</span> Make.com scenarios live</div>
              <div><span class="tok-green">✓</span> Slack channels wired</div>
              <div><span class="tok-green">✓</span> Dashboards populated</div>
              <div><span class="tok-dim">delivered in 90 days</span></div>
            </div>
          </div>
        </div>
        <div class="bento-card b4">
          <h4>You own it. <em>No lock-in.</em></h4>
          <p>The system lives inside your Airtable, your Make.com, your Slack. Cancel any time and the operating system keeps running. The updates and support stop. The infrastructure stays.</p>
          <div class="bento-visual">
            <div class="mock-bars">
              <div class="mock-bar" style="height: 60%"></div>
              <div class="mock-bar" style="height: 45%"></div>
              <div class="mock-bar" style="height: 75%"></div>
              <div class="mock-bar" style="height: 55%"></div>
              <div class="mock-bar" style="height: 85%"></div>
              <div class="mock-bar" style="height: 70%"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- HOW IT WORKS -->
  <section class="how" id="how">
    <div class="section-head">
      <div class="eyebrow">How it works</div>
      <h2>Three months in. <em>Then it runs without you.</em></h2>
      <p>No discovery deck. No 60-day audit. We start building from week one.</p>
    </div>
    <div class="how-grid">
      <div class="how-card">
        <div class="how-num">1</div>
        <h3>Conversation</h3>
        <p>30 minutes. We look at your business, your numbers, where it's leaking time and money. If it's a fit, we book the start date. If it's not, we tell you.</p>
      </div>
      <div class="how-card">
        <div class="how-num">2</div>
        <h3>Implementation (months 1–3)</h3>
        <p>We build the operating system around your actual business. Data model, automations, SOPs, dashboards. You're involved as much or as little as you want.</p>
      </div>
      <div class="how-card">
        <div class="how-num">3</div>
        <h3>Run it (month 4 onwards)</h3>
        <p>System goes live. £247/month covers ongoing support, updates and refinements. The business runs without you watching it.</p>
      </div>
    </div>
  </section>

  <!-- PRICING -->
  <section class="pricing" id="pricing">
    <div class="pricing-inner">
      <div class="section-head">
        <div class="eyebrow">Pricing</div>
        <h2>One offer. <em>One price.</em></h2>
        <p>No tiers, no upsells, no enterprise sales process. Done-for-you implementation plus ongoing support.</p>
      </div>
      <div class="price-grid price-grid-single">
        <div class="price-card featured">
          <div class="price-badge">Done-for-you implementation</div>
          <div class="price-tier">Operations OS</div>
          <div class="price-tagline">For founder-led businesses ready to take themselves out of the middle</div>
          <div class="price-amount">
            <div class="price-num">£1,997</div>
            <div class="price-unit">one-off implementation</div>
          </div>
          <div class="price-sub price-sub-emphasis">Then £247/month from month 4 · Minimum 12 months</div>
          <ul class="price-features">
            <li>Full operating system built around your business</li>
            <li>Airtable + Make.com + Slack + Claude AI layer</li>
            <li>Data model, automations, SOPs and dashboards</li>
            <li>End-to-end implementation over 90 days</li>
            <li>Ongoing support, updates and refinements</li>
            <li>You own everything. No lock-in.</li>
          </ul>
          <a class="price-cta" href="https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0" target="_blank" rel="noopener">Book a conversation →</a>
        </div>
      </div>
      <p class="price-footnote">VAT applied where applicable. We'll discuss terms on the call.</p>
    </div>
  </section>

  <!-- IS THIS A FIT -->
  <section class="how how-fit">
    <div class="section-head">
      <div class="eyebrow">Is this a fit?</div>
      <h2>Built for <em>founder-led businesses</em> where everything still depends on you.</h2>
    </div>
    <div class="how-grid">
      <div class="how-card">
        <h3>You'll get value if</h3>
        <p>You turn over £100k+, have 1–20 staff, and the business stops working when you take a week off. You've tried tools. You don't want another one.</p>
      </div>
      <div class="how-card">
        <h3>You won't if</h3>
        <p>You want strategy advice, a coach, or someone to tell you what to do. We don't coach. We build.</p>
      </div>
      <div class="how-card">
        <h3>What happens next</h3>
        <p>30-minute conversation. We look at your numbers and how the business runs today. No pressure. No pitch. Just a proper discussion.</p>
      </div>
    </div>
  </section>

  <!-- FINAL CTA -->
  <section class="final">
    <div class="final-inner">
      <h2>Stop running the business <em>in your head.</em></h2>
      <p>Book a 30-minute conversation. We'll look at your business, your numbers, and whether this is a fit.</p>
      <a class="btn-primary" href="https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0" target="_blank" rel="noopener">Book a conversation <span class="arrow">→</span></a>
    </div>
  </section>

</main>
<?php get_footer(); ?>
