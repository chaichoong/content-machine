<?php
/**
 * Fallback template — WordPress requires this file even if it's never used.
 * Redirects to whatever the front page is configured to show.
 *
 * @package OperationsDirector
 */
get_header();
?>
<main class="od-page-default">
	<article class="story" style="padding: 60px 24px;">
		<?php
		if ( have_posts() ) :
			while ( have_posts() ) :
				the_post();
				the_title( '<h2>', '</h2>' );
				the_excerpt();
			endwhile;
		else :
			echo '<p>Nothing here yet.</p>';
		endif;
		?>
	</article>
</main>
<?php get_footer(); ?>
