<?php
/**
 * Default page template — used for any WordPress page that doesn't select a
 * specific Template Name.
 *
 * @package OperationsDirector
 */
get_header();
?>
<main class="od-page-default">
	<article class="story" style="padding: 60px 24px;">
		<?php
		while ( have_posts() ) :
			the_post();
			the_title( '<h1>', '</h1>' );
			the_content();
		endwhile;
		?>
	</article>
</main>
<?php get_footer(); ?>
