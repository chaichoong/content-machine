<?php
/**
 * Template Name: FAQ
 * Description: Frequently asked questions — aligned to single-offer launch (£1,997 + £247/mo).
 *
 * @package OperationsDirector
 */
get_header();
?>
<main class="od-page-faq">
  <section class="faq">
    <div class="section-head" style="text-align:left;">
      <div class="eyebrow">Questions</div>
      <h2 style="margin-left:0; margin-right:0;">Straight answers, <em>no fluff.</em></h2>
    </div>
    <div class="faq-list">

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">What am I actually paying for?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">Two things. First, a £1,997 implementation: 90 days of building the operating system around your business — data model, automations, SOPs, dashboards, all wired together. Second, £247/month from month 4 for ongoing support, updates and refinements. Minimum 12 months.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">What's actually delivered?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">A working operating system that lives inside your own Airtable, Make.com, Slack and Claude accounts. Not a template. Not a workshop. Not a strategy deck. We build it. You use it.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">Do I need Airtable, Make.com, Slack or Claude already?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">No. We'll set them up if you don't have them. You'll need paid accounts on those platforms (their pricing is separate from ours). Everything we build lives in your accounts, not ours.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">Why a 12-month minimum?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">Because the value isn't in the build alone — it's in the ongoing refinement. Three months to deliver, then nine months of tuning the system around how your business actually changes. Less than that and you don't get the full value.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">What happens if I cancel after 12 months?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">You keep everything. The operating system lives in your Airtable, Make.com and Slack. Updates and support stop. The infrastructure stays running.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">Is my data safe?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">Your data never touches our servers. It lives in your Airtable, your Make.com, your Slack. We build on platforms with enterprise-grade security. NDAs signed as standard.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">How is this different from Notion or Airtable templates?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">Templates give you a blank database and a manual. We deliver a working system — data model, automations, AI layer, SOPs and dashboards — built around your actual business. You don't configure. You use.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">What size business is this built for?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">Founder-led businesses, £100k+ turnover, 1–20 staff, where everything still depends on the founder. Smaller than that and the spend isn't justified. Bigger than 20 staff, talk to us — there may be a different fit.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">Do I need technical skills?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">No. The system is built for non-technical operators. Your team uses Slack, fills Airtable forms, reads dashboards. The technical layer runs in the background and is maintained by us.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">Can you integrate with tools I already use?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">Usually, yes. We integrate with Gmail, Google Workspace, GoHighLevel, Xero, QuickBooks, Stripe, HubSpot, Pipedrive and dozens of others via Make.com. If a tool has an API, we can connect it.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">Do you do strategy or coaching?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">No. We don't coach. We build. If you want strategy advice or someone to tell you what to do, this isn't the right fit.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">Why should I trust Operations Director?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">Because every system we build runs inside our own businesses first — a multi-city property portfolio, a consultancy, and a charity brand. We don't sell theory. We sell what we use.</div>
      </div>

      <div class="faq-item" onclick="toggleFaq(this)">
        <div class="faq-q"><div class="faq-qtext">How do I get started?</div><div class="faq-toggle">+</div></div>
        <div class="faq-a">Book a 30-minute conversation. We'll look at your business, your numbers, and whether this is a fit. No pressure. No pitch.</div>
      </div>

    </div>

    <div style="text-align:center; margin-top:48px;">
      <a class="btn-primary" href="https://api.leadconnectorhq.com/widget/booking/BcVVhAg1zLaPVEXj5ih0" target="_blank" rel="noopener">Book a conversation <span class="arrow">→</span></a>
    </div>
  </section>

</main>
<?php get_footer(); ?>
